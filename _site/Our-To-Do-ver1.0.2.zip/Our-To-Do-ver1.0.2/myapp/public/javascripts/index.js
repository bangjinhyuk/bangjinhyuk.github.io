const startButton = document.getElementById("start-button");
startButton.addEventListener("click", (e) => {
  location.href = "/user/login";
});
const guitdeButton = document.getElementById("start-guide");
guitdeButton.addEventListener("click", (e) => {
  location.href =
    "https://github.com/HyoTaek-Jang/Our-To-Do/blob/master/%EC%82%AC%EC%9A%A9%EC%9E%90%EA%B0%80%EC%9D%B4%EB%93%9C.md";
});
