## 21년 2월 21일 ver1.0.2 업데이트

- AutoLogin 버그 수정
- Bookmark 클릭 시 새창에서 열리도록 수정
- 날씨 아이콘 추가
- 반응형 박스 사이징
- Todo, Bookmark 추가 시, 로직 변경 ( DB추가와 화면 생성을 따로 분리 )
- Todo, Bookmark 드래그를 통한 인덱스 조정 기능 추가

---

## 21년 2월 17일 ver1.0.1 업데이트

- Login 기능에서 Enter를 통한 submit 구현
- Login Placehold 수정
- 북마크 URL 자동 http 프로토콜 추가 기능 버그 업데이트
- db 북마크 링크 길이 제한 해제
- 푸터 작업을 통한 사용자 문의사항 창구 개설
